'use strict'

const config = {
  'uc': {
    login_name: 'waf_loginer',
    password: '80fba977d063a6f7262a8a9c95f61140',
    aws_password: ''
  },
  'classmember': {
    host: 'http://cs.101.com',
    serverName: 'classmember_gateway',
    serverId: '689678df-5843-41c3-a993-4c00a6974334',
    localPath: 'E:\\work\\classmember-gateway\\gerrit\\src\\main\\webapp',
  },
  'studymap': {
    host: 'http://cs.101.com',
    serverName: 'studymap_gateway',
    serverId: 'dfd0f102-fa3e-4707-bf95-2bb1f093c38f',
    localPath: 'E:\\work\\elearning-studymap-gateway\\gerrit\\src\\main\\webapp',
  },
  'dynamic_loading': {
    host: 'http://cs.101.com',
    serverName: 'team7_cs',
    serverId: 'd7d8b2a1-c472-4d2b-8754-a6830769462e',
    localPath: 'E:\\work\\react-boilerplate-master\\dynamic_loading',
  },
  'eduLibs': {
    host: 'http://cs.101.com',
    serverName: 'team7_cs',
    serverId: 'd7d8b2a1-c472-4d2b-8754-a6830769462e',
    localPath: 'E:\\work\\react-boilerplate-master\\cdnLibs',
  },
  'feedback': {
      host: 'http://cs.101.com',
      serverName: 'elearning_feedback_gateway',
      serverId: 'ac4296ac-f8ad-47f9-80eb-6cff05607efe',
      localPath: 'E:\\work\\feedback-gateway\\gerrit\\src\\main\\webapp',
  },
  'diyform': {
      host: 'http://cs.101.com',
      serverName: 'diyform_gateway',
      serverId: '4cabc076-2cb2-4a8e-b309-819af36299b3',
      localPath: 'E:\\work\\diyform-gateway\\gerrit2\\src\\main\\webapp',
  },
  'userselect': {
    host: 'http://cs.101.com',
    serverName: 'userselect_gateway',
    serverId: '97a45cf4-2b61-48fa-8653-7a3f88d55c65',
    localPath: 'E:\\work\\user-select-gateway\\gerrit\\src\\main\\webapp',
  }
}






// 以下代码不要修改
let appName = process.argv[2] || 'appName'
if (!config[appName]) {
  console.error('\x1B[31m%s\x1B[39m', `配置错误，config.js 文件缺少对应用 "${appName}" 的配置`)
  process.exit()
}

let output = {
  uc: config.uc,
  cs: config[appName]
}

module.exports = output

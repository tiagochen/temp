'use strict';

const fs = require('fs-extra');
const requestPromise = require('request-promise');
const configInfo = require('./config');

/**
 * 一次性覆盖上传
 * 参考CS API: http://wiki.sdp.nd/index.php?title=%E5%86%85%E5%AE%B9%E6%9C%8D%E5%8A%A1all_new#.E4.B8.80.E6.AC.A1.E6.80.A7.E8.A6.86.E7.9B.96.E4.B8.8A.E4.BC.A0
 * @param {*} uploadFilePath 要上传的本地文件路径
 * @param {*} filePath CS上存放路径
 */
function uploadFileToCs(uploadFilePath, filePath) {
    return getSession()
        .then((session) => {
            var csHost = configInfo['cs']['host'];
            var uri = `${csHost}/v0.1/upload?session=${session}&rename=false`;
            var formData = {
                // Like <input type="text" name="name">
                filePath: `/${configInfo['cs']['serverName']}${filePath}`,
                // Like <input type="file" name="file">
                file: fs.createReadStream(uploadFilePath),
                scope: 1
            }

            return postForObjectWithForm(uri, formData);
        });
}

/**
 * 获取session值
 * 参考CS API: http://wiki.sdp.nd/index.php?title=%E5%86%85%E5%AE%B9%E6%9C%8D%E5%8A%A1all_new#.E8.8E.B7.E5.8F.96session_.5BPOST.5D_.2Fv0.1.2Fsessions
 */
function getSession() {
    return getAccessToken()
        .then((token) => {
            let csRequestBody = {};
            csRequestBody.path = `/${configInfo['cs']['serverName']}`;
            csRequestBody.uid = '100000101';
            csRequestBody.role = 'admin';
            csRequestBody.service_id = configInfo['cs']['serverId'];
            csRequestBody.expires = 300;

            var csHost = configInfo['cs']['host'];
            var uri = `${csHost}/v0.1/sessions`;

            return postForObjectWithJson(uri, token, csRequestBody)
        }).then((responseBody) => {
            return responseBody.session; 
        });
}

/**
 * 获取access_token值
 * 参考UC API: http://wiki.sdp.nd/index.php?title=UC_API_RestfulV0.93#.5BPOST.5D.2Fbearer_tokens_.E6.9C.8D.E5.8A.A1.E7.AB.AF.E7.99.BB.E5.BD.95.5BS.5D
 */
function getAccessToken() {
    let ucRequestBody = {};
    ucRequestBody.login_name = configInfo['uc']['login_name'];
    ucRequestBody.password = configInfo['uc']['password'];

    var csHost = configInfo['cs']['host'];
    var ucHost = '';

    if (csHost.indexOf('sdpcs.beta.web.sdp.101.com') >= 0 || csHost.indexOf('betacs.101.com') >= 0) {
        ucHost = 'https://ucbetapi.101.com';
    } else if (csHost.indexOf('awscs.101.com') >= 0) {
        ucHost = 'https://awsuc.101.com';
    } else if (csHost.indexOf('cs-awsca.101.com') >= 0) {
        ucHost = 'https://uc-awsca.101.com';
    } else {
        ucHost = 'https://aqapi.101.com';
    }

    var uri = `${ucHost}/v0.93/bearer_tokens`;
    return postForObjectWithJson(uri, '', ucRequestBody)
        .then((responseBody) => {
            return responseBody.access_token; 
        });
}

/**
 * POST data to a JSON REST API
 * @param {*} uri 请求地址
 * @param {*} token 用于设置Authorization认证
 * @param {*} requestBody 请求内容
 */
function postForObjectWithJson(uri, token, requestBody) {
    // console.log(`[INFO] POST ${uri}`);
    // console.log(`[INFO] REQUEST BODY: ${JSON.stringify(requestBody)}`);
    
    var options = {
        method: 'POST',
        uri: uri,
        body: requestBody,
        headers: {},
        json: true // Automatically stringifies the body to JSON
    };

    if (token !== '') {
        options.headers.Authorization = `Bearer "${token}"`;
    }
 
    return requestPromise(options)
        .then(function (responseBody) {
            // console.log(`[INFO] RESPONSE BODY: ${JSON.stringify(responseBody)}`);
            return responseBody; 
        })
        .catch(function (err) {
            console.error(`[ERROR] request failed: ${err}`);
            throw new Error(`request failed: ${err}`);
        });
}

/**
 * POST like HTML forms do
 * @param {*} uri 请求地址
 * @param {*} formData 表单数据
 */
function postForObjectWithForm(uri, formData) {
    // console.log(`[INFO] POST ${uri}`);
    // console.log(`[INFO] REQUEST BODY: ${JSON.stringify(formData)}`);
    
    var options = {
        method: 'POST',
        uri: uri,
        formData: formData,
        headers: {
            'Content-Type': 'multipart/form-data'
        }
    };
    
    return requestPromise(options)
    .then(function (responseBody) {
        // console.log(`[INFO] Upload successful! Server responded with: ${responseBody}`);
        return responseBody;
    }).catch(function (err) {
        // console.error(`[ERROR] upload failed: ${err}`);
        throw new Error(`upload failed: ${err}`);
    });
}

module.exports = {
    uploadFileToCs: uploadFileToCs,
    postForObjectWithJson: postForObjectWithJson
};
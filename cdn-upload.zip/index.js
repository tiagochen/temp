/**
 * node index.js 工程名称 环境(dev, debug, beta, prod)
 *  eg: node index.js classmember debug
 */


'use strict'

const rd = require('rd')
const path = require('path')
const configInfo = require('./config')
const csSdk = require('./cs-sdk')
let appEnv = process.argv[3] || ''

function doStuff() {
  let targetCount = 0
  rd.eachSync(configInfo.cs.localPath, function (f, s) {
    if (s.isDirectory()) {
      return
    }
    ++targetCount
  })

  // 同步遍历目录下的所有文件
  rd.eachSync(configInfo.cs.localPath, function (f, s) {
    if (s.isDirectory()) {
      return
    }
    let fileName = path.parse(f).base
    let dir = f.replace(configInfo.cs.localPath, '').replace(fileName, '').replace(/\\/g, '/')
    let targetDir = `/${appEnv}${dir}${fileName}`
    // console.log(f, '=>', targetDir)
    csSdk.uploadFileToCs(f, targetDir).then(() => {
      console.log(`upload finish: ${f} => ${targetDir}`)
      if (--targetCount === 0) {
        console.log('\x1B[32m%s\x1B[39m', 'Success!')
      }
    })
  })
}

const readline = require('readline');

//创建readline接口实例
const  rl = readline.createInterface({
  input:process.stdin,
  output:process.stdout
});


if(appEnv !== 'dev' && appEnv !== 'debug' && appEnv !== 'beta') {
  rl.question("你确定要发布生产环境吗？（input 'yyy' to make sure) ",function(answer){
    rl.close();
    if( answer !== 'yyy' ) {
      console.log('程序退出!')
      process.exit(0);
    }
    doStuff()
  });
} else {
  doStuff()
}